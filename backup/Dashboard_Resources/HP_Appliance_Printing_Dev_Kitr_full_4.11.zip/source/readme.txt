To view the full html deveoper's guide open http://doc/index.html
To view or print the full pdf developer's guide open doc\devguide.pdf
To view the release notes for this version only open http://doc/releasenotes.html