namespace sf.net.lpdnet.common
{
	/// <summary>
	/// Holds the data of a print job
	/// </summary>
	public class DataFile : PrintFile
	{
		/// <summary>
		/// Data file class
		/// </summary>
		public DataFile()
		{
		}
	}
}