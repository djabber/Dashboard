using NUnit.Framework;

namespace sf.net.lpdnet.test
{
	/// <summary>
	/// 
	/// </summary>
	[TestFixture]
	public abstract class TestBase
	{
	}
}